#ifndef PRUEBA_IM_H
#define PRUEBA_IM_H

#include <systemc.h>

    class pruebaIM : public sc_module
    {    
    public:
        
        sc_out<sc_int<32>> testOut;
        sc_in<bool> testAgain;
        SC_CTOR(pruebaIM);
        sc_in<bool> clkIn;
    private:
        void test();

    };
    
    


#endif