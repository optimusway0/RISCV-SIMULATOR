#include "pruebaIM.h"


pruebaIM::pruebaIM(sc_module_name moduleName) : sc_module(moduleName) {

    SC_THREAD(test);  
    
    sensitive<<clkIn.pos();     
    dont_initialize();
}

void pruebaIM::test(){

    testOut.write(4);
     std::cout << sc_time_stamp() << "    ";
    wait();
    testOut.write(4);
     std::cout << sc_time_stamp() << "    ";
    wait();
    testOut.write(4);
     std::cout << sc_time_stamp() << "    ";    

    sc_stop(); 
}