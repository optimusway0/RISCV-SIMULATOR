#include "RegisterFile.h"


RegisterFile::RegisterFile(sc_module_name nm) : sc_module(nm){
    
    // for (int i = 7; i < 19; i++)
    // {
    //   storage[i] = i; //Que inicialice con esos valores en los registros donde se almacenan los datos. 
    // }
    
    SC_METHOD(operation); 
   sensitive<< rwIn <<raIn << rbIn;     
}

void RegisterFile::operation(){           
            
        
    //aOut = storage[raIn.read()];
    //bOut = storage[rbIn.read()];



cout<<"a"<<"raIn: "<<raIn.read()<<" rbIn: "<<rbIn.read()<<" rwIn: "<<rwIn.read()<<" "<<endl;

    //cout<<"aOut: "<<aOut<<endl;
    //cout<<"bOut: "<<bOut<<endl;

    //cout<<"!!!";
    // if (weIn.read())
    // {
    //    storage[rwIn.read()] = wIn.read();
    // }       
    
    
}






