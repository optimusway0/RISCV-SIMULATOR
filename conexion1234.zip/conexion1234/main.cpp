#include<iostream>
#include<systemc.h>
#include "ALU/alu.h"
#include "ALU/MuxEX.h"
#include "MEM-WB/DataMemory.h"
#include "MEM-WB/Mux.h"
#include "MEM-WB/AndGate.h"

#include "IF-ID/ProgramCounter.h"
#include "IF-ID/Adder.h"
#include "IF-ID/MuxIF.h"
#include "IF-ID/InstructionMemory.h"
#include "IF-ID/TestbenchIF.h"
#include "ID-EX/RegisterFile.h"
#include "ID-EX/SignalExpand.h"

int sc_main (int argv, char* argc[]) 
{   
    sc_time period(10,SC_NS);
    sc_time delay(10,SC_NS);
    sc_clock clock("clock", period, 0.5, delay, true);

    InstructionMemory IM("IM");
    ProgramCounter PC("PC");
    Adder ADD("ADD");
    MuxIF MuxIF("MuxIF");
    MuxEX MuxEx("MuxEx");
    RegisterFile RF("RF");
    TestbenchIF tb("tb");
    SignalExpand se("se");
    Alu ALU("ALU");


    sc_signal< sc_int<32> > MuxIFSg, PcSg, AddSg, RF1, RF2, ALUSg;

    sc_signal< sc_int<32> > TbSga, pSignalSg, bSg, muxExSg;
    sc_signal< bool > TbSgb, TbSgc;

    sc_signal< sc_uint<5> > rdSg, rs1Sg, rs2Sg, opcodeSg;
    sc_signal< sc_int<12> > immSg;

    MuxIF.aIn(TbSga);
    MuxIF.sIn(TbSgb);
    MuxIF.aOut(MuxIFSg);

    ADD.aIn(MuxIFSg);
    ADD.bIn(PcSg);
    ADD.aOut(AddSg);

    PC.aIn(AddSg);
    PC.clkIn(clock);
    PC.aOut(PcSg);

    IM.counterIn(PcSg);
    IM.rd(rdSg);
    IM.rs1(rs1Sg);
    IM.rs2(rs2Sg);
    IM.imm(immSg);
    IM.opcode(opcodeSg);

    RF.rd(rdSg);
    RF.rs1(rs1Sg);
    RF.rs2(rs2Sg);
    RF.aOut(RF1);
    RF.bOut(bSg);
 
    se.immIn(immSg);
    se.immOut(pSignalSg);    

    //Conexion Multiplexor EX
    MuxEx.aIn(pSignalSg);
    MuxEx.bIn(bSg);
    MuxEx.s0In(TbSgc);
    MuxEx.cOut(muxExSg);     //Salida del MuxEx hacia la ALU

    ALU.aIn(RF1);
    ALU.bIn(muxExSg);
    ALU.ALUOpIn(opcodeSg);
    ALU.aluResultOut(ALUSg);

    tb.pc(PcSg);
    tb.rs1(RF1);
    tb.rs2(RF2);
    tb.imm(muxExSg);
    tb.opcode(opcodeSg);
    tb.result(ALUSg);
    tb.clkIn(clock);

    tb.MuxEx(TbSgc);
    tb.jump(TbSga);
    tb.eJump(TbSgb);

    sc_start();


    return 0;
}