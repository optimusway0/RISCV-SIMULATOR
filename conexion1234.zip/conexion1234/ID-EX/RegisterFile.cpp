#include "RegisterFile.h"
RegisterFile::RegisterFile(sc_module_name nm) : sc_module(nm){
    
    // for (int i = 7; i < 19; i++)
    // {
    //   storage[i] = i; //Que inicialice con esos valores en los registros donde se almacenan los datos. 
    // }
    
    SC_METHOD(operation); 
    sensitive<< rd << rs1 << rs2;     
}

void RegisterFile::operation(){           

    aOut.write(storage[rs1.read()]);
    bOut.write(storage[rs2.read()]);

    //cout<<"a"<<"raIn: "<<rs1.read()<<" rbIn: "<<rs2.read()<<" rwIn: "<<rd.read()<<" "<<endl;

    //cout<<"aOut: "<<aOut<<endl;
    //cout<<"bOut: "<<bOut<<endl;

    //cout<<"!!!";
    // if (weIn.read())
    // {
    //    storage[rwIn.read()] = wIn.read();
    // }       
    
    
}






